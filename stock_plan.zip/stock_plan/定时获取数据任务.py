# -*- coding: utf-8 -*-
"""
Created on Fri Mar 28 13:25:52 2025

@author: evang

定时获取数据任务
"""


import time
from datetime import datetime
from Tushare_Stock_data import send_meg

def task():
    print("执行任务",datetime.now())


if __name__=='__main__':
    time_start=['13','30']#设置定时时间 如 13：30

    while True:
        now = datetime.now()
        if now.hour == 14 and now.minute == 42:
            send_meg()
            # break
        time.sleep(60)