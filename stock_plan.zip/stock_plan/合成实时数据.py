import tushare as ts
import time
import pandas as pd

def his_time():
    taken='975c3d89ad017dfd7bce59d7b232a38e0f00c7237e1e326c03b00e3c'
    pro = ts.pro_api()
    df = pro.daily(ts_code='600028.SH')
    return  df
    # print(df)

def ontime():
    df = ts.realtime_quote('600028.SH')
    return df
if __name__=='__main__':
    i=0
    df_all=ontime()
    while i<3:
        a=ontime()
        # df_all=df_all.append(a)
        df_all=pd.concat([df_all,a],axis=0)
        i+=1
        time.sleep(10)
    print(df_all)
    df_all.to_excel('.//212.xlsx')
