
import tushare as ts
taken='975c3d89ad017dfd7bce59d7b232a38e0f00c7237e1e326c03b00e3c'
class Get_data(object):
    def __init__(self,ts_code):
        self.ts_code=ts_code
    def data_ontime(self):#生成实时的数据
        df = ts.realtime_quote(self.ts_code)
        print(df)
        return df
    def data_history(self,start_date='20180701',end_date='20250329'):
        pro = ts.pro_api()
        df = pro.daily(ts_code=self.ts_code)
        print(df)
if __name__=='__main__':
   Get_data('600028.SH').data_ontime()
   Get_data('600028.SH').data_history()

