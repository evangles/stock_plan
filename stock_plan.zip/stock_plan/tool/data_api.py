import akshare as ak
import tushare as ts
"""股票应用tushare 库-ts_code，期货akshare 库参数-af_code

"""

def getdel_data(af_code):#应用于concat 多列生成hotmap
    futures_zh_daily_sina_df = ak.futures_zh_daily_sina(symbol=af_code)
    df = futures_zh_daily_sina_df
    df = df.loc[:, ['date', 'close']]
    df = df.set_index('date')#将时间序列转为index，方便合并
    df.columns = [af_code]
    return df
def futures_zh_daily_sina(af_code):#ak.futures_hist_table_em()调取期货品种
    # columns=[date    open    high     low   close  volume  hold  settle]
    df = ak.futures_zh_daily_sina(symbol=af_code)
    df=df.loc[:,['date','close']]

    return df
def futures_zh_minute_sina(af_code,zq):#生成分钟图period参数范围(1.5.15，30，60)
    #columns='datetime', 'open', 'high', 'low', 'close', 'volume', 'hold'
    df = ak.futures_zh_minute_sina(symbol=af_code, period=zq)
    df=df.loc[:,['datetime','close']]
    df.columns=['date','close']
    return df

def stock_ontime(ts_code):
    ''''collumns=['NAME', 'TS_CODE', 'DATE', 'TIME', 'OPEN', 'PRE_CLOSE', 'PRICE', 'HIGH',
       'LOW', 'BID', 'ASK', 'VOLUME', 'AMOUNT', 'B1_V', 'B1_P', 'B2_V', 'B2_P',
       'B3_V', 'B3_P', 'B4_V', 'B4_P', 'B5_V', 'B5_P', 'A1_V', 'A1_P', 'A2_V',
       'A2_P', 'A3_V', 'A3_P', 'A4_V', 'A4_P', 'A5_V', 'A5_P']
    '''
    #设置你的token，登录tushare在个人用户中心里拷贝
    ts.set_token('975c3d89ad017dfd7bce59d7b232a38e0f00c7237e1e326c03b00e3c')

    #sina数据
    df = ts.realtime_quote(ts_code=ts_code)
    # df=df.loc[:,['NAME','TS_CODE','TIME','PRICE']]
    df = df.loc[:, ['TIME','PRICE']]
    df.columns = ['date', 'close']
    return df
def stock_histroy_daliy(ts_code,start_date,end_date):
    #'ts_code', 'trade_date', 'open', 'high', 'low', 'close', 'pre_close', 'change', 'pct_chg', 'vol', 'amount']
    #设置你的token，登录tushare在个人用户中心里拷贝
    ts.set_token('975c3d89ad017dfd7bce59d7b232a38e0f00c7237e1e326c03b00e3c')
    pro = ts.pro_api()

    df = pro.daily(ts_code=ts_code, start_date=start_date, end_date=end_date)
    df=df[::-1]#将顺序调整
    df = df.loc[:, ['trade_date','close']]
    df.columns = ['date', 'close']
    return df
if __name__=='__main__':#600000.SH rb2602
    ts_code='600000.SH'
    af_code='rb2602'
    zq=60
    df=stock_histroy_daliy('600000.SH', start_date='20250105', end_date='20250519')
    # df=stock_ontime(ts_code)
    # df=futures_zh_minute_sina(af_code,zq)
    # df=futures_zh_daily_sina(af_code)
    print(df.columns)