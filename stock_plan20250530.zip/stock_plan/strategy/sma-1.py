# -*- coding: utf-8 -*-
"""
Created on Fri Dec 13 14:35:55 2024

@author: Administrator
"""
import sys

from mpmath.libmp import round_down

sys.path.insert(0, "..")#添加路径导入上级的函数
from tool.data_api import futures_zh_daily_sina,futures_zh_minute_sina,stock_ontime,stock_histroy_daliy
import akshare as ak

import pandas as pd
import numpy as np
class F_sma(object):
    # 以证券的品种及长线短线作为参数
    def __init__(self,ak_code,long_size,short_size):
        self.ak_code=ak_code
        self.long_size=long_size
        self.short_size=short_size
        self.start_date ='20240101'
        self.stop_date ='20255101'
    def sma(self):
        # 删选列表
        # df=futures_zh_daily_sina(self.ak_code)
        df=stock_histroy_daliy(self.ak_code,self.start_date,self.stop_date)

        df.index=df.pop('date')#删除并将日期作为索引



        # 向下偏移一个单位的目的是避免未来函数，以为不向下偏移会计算当前价格
        df['mean_short']=df['close'].rolling(self.short_size).mean()
        df['short']=df['mean_short'].shift(1)
        
        df['mean_long']=df['close'].rolling(self.long_size).mean()
        df['long']=df['mean_long'].shift(1)



        # 生成列表
        df['signal_long']=(df['short'].shift(1)<=df['long'].shift(1))&(df['short']>df['long'])#做多信号

        df['signal_short']=(df['short'].shift(1)>=df['long'].shift(1))&(df['short']<df['long'])#做空新号
        df=df[(df['signal_long']==True)|(df['signal_short']==True)]
        df.to_excel('.//zhibiaoxian.xlsx')

        return df   # 返回表格
    def sma_stock_divident(self):#增加股息补偿

        pass
    def re_sma(self):#回溯模块
        df=self.sma()
        profit_cum_list = []  # 初始收益列表
        profit_cum = 0
        #================================
        cash = 50000#初始金额
        hold_cash=0#初始金额0
        commission_ratio = 0.0002#佣金率
        slippage_ratio = 0.0001#滑点率
        Positions_ratio=0.7#仓位操作率
        bill_s=0#持有股票数量
        trans_fee=5#交易费5元


        #================================
        hold_state = 0  # 持仓状态
        hold_price_A = 0  # 持仓价格
        dic_return = {} #需要返回的指标数据等

        sig_long = df['signal_long']
        sig_short = df['signal_short']
        price = df['close'].values

        # 1/2仓买入全仓出
        for i in range(0, len(price)):
            if hold_state == 0:  # 当未持仓时候，判断产生持多的信号后，产生当前价格，打开持仓状态
                if sig_long[i] == True:
                    hold_price_A = price[i]
                    hold_state = 1
                    bill_s=round((0.01*Positions_ratio*cash)/hold_price_A)#持有证券数量
                    cash=cash-(bill_s*hold_price_A)*100*(1+slippage_ratio+slippage_ratio)#现金余额

                    hold_cash=hold_price_A*bill_s*100#证券资产
                    catpital=cash + hold_cash
                    print(cash,hold_price_A, bill_s, hold_cash,catpital,'买入')
            else:  # 当持仓状态并且产向下的信号时候,卖出，并累计收益
                if hold_state == 1 and sig_short[i] == True:
                    profit = (price[i]-hold_price_A)*100*bill_s
                    profit_cum += profit
                    hold_state = 0
                    cash=cash+price[i]*100*bill_s-trans_fee
                    print(cash,price[i],'卖出')
                    hold_cash=0
                    bill_s=0
                    catpital=cash + hold_cash
            profit_cum_list.append(profit_cum)
        print(profit_cum_list,profit_cum)
        # 返回一个字典返回相关的标准值，以字典的形式
        dic_return['profit_cum_nao'] = round(profit_cum,3)
        dic_return['times'] = len(profit_cum_list)
        dic_return['cash']=round(cash)
        dic_return['catpital']=catpital
        return dic_return


if __name__=='__main__':
    af_code = '600028.SH'
    # af_code = 'rb2506'
    long_size=7
    short_size=3
    a=F_sma(af_code,long_size,short_size)
    df=a.re_sma()

    print(df)

       
